#!/usr/bin/env bash

ros install cxxxr/lem cxxxr/cl-lsp
