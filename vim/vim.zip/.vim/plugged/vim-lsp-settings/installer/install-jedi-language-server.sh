#!/usr/bin/env bash

set -e

"$(dirname "$0")/pip_install.sh" jedi-language-server jedi-language-server
