---
name: Bug report
about: Report vim-polyglot bug
title: ''
labels: ''
assignees: ''

---

<!-- Vim-polyglot is not responsible for bugs of plugins it uses. Please report only bugs that happen when plugin is used as part of vim-polyglot and doesn't happen when just install the plugin -->

**Does this bug happen when you install plugin without vim-polyglot?**

**Describe the bug:**

**To Reproduce:**
