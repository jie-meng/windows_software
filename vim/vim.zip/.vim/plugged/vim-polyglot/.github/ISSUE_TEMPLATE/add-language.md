---
name: Add language
about: Add support for new language
title: ''
labels: 'enhancement'
assignees: ''

---

**What is the name of this language in Linguist?**

<!-- https://github.com/github/linguist/blob/master/lib/linguist/languages.yml -->

**Link to GitHub repository of Vim plugin**



**Is this plugin well maintained?**



**Is this plugin lightweight? (no advanced functionality, just indent and syntax support)**


