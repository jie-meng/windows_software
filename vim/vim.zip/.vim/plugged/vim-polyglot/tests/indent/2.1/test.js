// File with 2-spaces indentation
function foobar() {
  foo = bar
  while (true) {
    fizfuz()
    fizfuz()
    fizfuz()
    fizfuz()
  }
}
