mod calc;

mod documentdefinition;
mod documentformat;

fn main() {
    println!("Hello, world!");
}
