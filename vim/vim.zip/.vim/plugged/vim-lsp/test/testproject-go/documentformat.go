package main
func main() {
print("hello, world!")
print("こんにちは、世界")
print("a β c")
print("δ")
}
